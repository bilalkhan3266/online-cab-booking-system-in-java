package com.mycompany.mavenproject32;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Booking Class
class Booking {
    private final String passengerUsername;
    private final String pickupLocation;
    private final String dropoffLocation;

    public Booking(String passengerUsername, String pickupLocation, String dropoffLocation) {
        this.passengerUsername = passengerUsername;
        this.pickupLocation = pickupLocation;
        this.dropoffLocation = dropoffLocation;
    }

    @Override
    public String toString() {
        return "Booking{" +
                "passengerUsername='" + passengerUsername + '\'' +
                ", pickupLocation='" + pickupLocation + '\'' +
                ", dropoffLocation='" + dropoffLocation + '\'' +
                '}';
    }
}

// Abstract User Class
abstract class User {
    private String username;
    private String password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}

// Driver Class
class Driver extends User {
    private String vehicleType;
    private String licensePlate;

    public Driver(String username, String password, String vehicleType, String licensePlate) {
        super(username, password);
        this.vehicleType = vehicleType;
        this.licensePlate = licensePlate;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public String getLicensePlate() {
        return licensePlate;
    }
}

// Passenger Class
class Passenger extends User {
    public Passenger(String username, String password) {
        super(username, password);
    }
}

// Booking System Class
class BookingSystem {
    private final Map<String, Driver> drivers = new HashMap<>();
    private final Map<String, Passenger> passengers = new HashMap<>();
    private final List<Booking> bookings = new ArrayList<>();
    private final String DRIVER_FILE = "drivers.txt";
    private final String PASSENGER_FILE = "passengers.txt";

    public BookingSystem() {
        loadDrivers();
        loadPassengers();
    }

    // Save Driver Data to File
    private void saveDriver(Driver driver) {
        try (FileWriter writer = new FileWriter(DRIVER_FILE, true)) {
            writer.write(driver.getUsername() + "," + driver.getPassword() + "," + driver.getVehicleType() + "," + driver.getLicensePlate() + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Save Passenger Data to File
    private void savePassenger(Passenger passenger) {
        try (FileWriter writer = new FileWriter(PASSENGER_FILE, true)) {
            writer.write(passenger.getUsername() + "," + passenger.getPassword() + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Load Drivers from File
    private void loadDrivers() {
        try (BufferedReader reader = new BufferedReader(new FileReader(DRIVER_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4) {
                    String username = parts[0];
                    String password = parts[1];
                    String vehicleType = parts[2];
                    String licensePlate = parts[3];
                    drivers.put(username, new Driver(username, password, vehicleType, licensePlate));
                }
            }
        } catch (IOException e) {
            System.out.println("No drivers found or unable to read drivers file.");
        }
    }

    // Load Passengers from File
    private void loadPassengers() {
        try (BufferedReader reader = new BufferedReader(new FileReader(PASSENGER_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    String username = parts[0];
                    String password = parts[1];
                    passengers.put(username, new Passenger(username, password));
                }
            }
        } catch (IOException e) {
            System.out.println("No passengers found or unable to read passengers file.");
        }
    }

    public void registerDriver(String username, String password, String vehicleType, String licensePlate) {
        Driver driver = new Driver(username, password, vehicleType, licensePlate);
        drivers.put(username, driver);
        saveDriver(driver);
        JOptionPane.showMessageDialog(null, "Driver registered successfully!");
    }

    public void registerPassenger(String username, String password) {
        Passenger passenger = new Passenger(username, password);
        passengers.put(username, passenger);
        savePassenger(passenger);
        JOptionPane.showMessageDialog(null, "Passenger registered successfully!");
    }

    public void bookCab(String passengerUsername, String pickupLocation, String dropoffLocation) {
        if (passengers.containsKey(passengerUsername)) {
            Booking booking = new Booking(passengerUsername, pickupLocation, dropoffLocation);
            bookings.add(booking);
            JOptionPane.showMessageDialog(null, "Cab booked successfully!\n" + booking);
        } else {
            JOptionPane.showMessageDialog(null, "Passenger not found!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

// Main Application Class with GUI
public class Mavenproject32 {
    private static BookingSystem system = new BookingSystem();

    public static void main(String[] args) {
        JFrame frame = new JFrame("Cab Booking System");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(4, 1));

        // Button for Driver Registration
        JButton registerDriverButton = new JButton("Register Driver");
        registerDriverButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = JOptionPane.showInputDialog("Enter Driver Username:");
                String password = JOptionPane.showInputDialog("Enter Password:");
                String vehicleType = JOptionPane.showInputDialog("Enter Vehicle Number:");
                String licensePlate = JOptionPane.showInputDialog("Enter License Number:");
                system.registerDriver(username, password, vehicleType, licensePlate);
            }
        });

        // Button for Passenger Registration
        JButton registerPassengerButton = new JButton("Register Passenger");
        registerPassengerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = JOptionPane.showInputDialog("Enter Passenger Username:");
                String password = JOptionPane.showInputDialog("Enter Password:");
                system.registerPassenger(username, password);
            }
        });

        // Button for Booking Cab
        JButton bookCabButton = new JButton("Book Cab");
        bookCabButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = JOptionPane.showInputDialog("Enter Passenger Username:");
                String pickup = JOptionPane.showInputDialog("Enter Pickup Location:");
                String dropoff = JOptionPane.showInputDialog("Enter Dropoff Location:");
                system.bookCab(username, pickup, dropoff);
            }
        });

        // Button for Exiting the Program
        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });

        // Add buttons to the frame
        frame.add(registerDriverButton);
        frame.add(registerPassengerButton);
        frame.add(bookCabButton);
        frame.add(exitButton);

        // Display the GUI window
        frame.setVisible(true);
    }
}
